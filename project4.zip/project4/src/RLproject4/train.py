
import torch
import numpy as np
from SAC import SAC
from gazebo_env import GazeboEnv
from replay_buffer import ReplayBuffer
from pretrain_utils import Pretraining
from pathlib import Path
from dataclasses import dataclass
import numpy as np

@dataclass
class pos_data:
    name = None
    x = None
    y = None
    angle = None

def check_position(x, y, element_positions, min_dist):
    pos = True
    for element in element_positions:
        distance_vector = [element[0] - x, element[1] - y]
        distance = np.linalg.norm(distance_vector)
        if distance < min_dist:
            pos = False
    return pos

def set_random_position(name, element_positions):
    angle = np.random.uniform(-np.pi, np.pi)
    pos = False
    while not pos:
        x = np.random.uniform(-4.0, 4.0)
        y = np.random.uniform(-4.0, 4.0)
        pos = check_position(x, y, element_positions, 1.8)
    element_positions.append([x, y])
    eval_element = pos_data()
    eval_element.name = name
    eval_element.x = x
    eval_element.y = y
    eval_element.angle = angle
    return eval_element

def record_eval_positions(n_eval_scenarios=10):
    scenarios = []
    for _ in range(n_eval_scenarios):
        eval_scenario = []
        element_positions = [[-2.93, 3.17], [2.86, -3.0], [-2.77, -0.96], [2.83, 2.93]]
        for i in range(4, 8):
            name = "obstacle" + str(i + 1)
            eval_element = set_random_position(name, element_positions)
            eval_scenario.append(eval_element)
        eval_element = set_random_position("turtlebot3_waffle", element_positions)
        eval_scenario.append(eval_element)
        eval_element = set_random_position("target", element_positions)
        eval_scenario.append(eval_element)
        scenarios.append(eval_scenario)
    return scenarios

def main(args=None):    
    action_dim = 2  
    max_action = 1  
    state_dim = 25  
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")  
    nr_eval_episodes = 10  
    max_epochs = 100  
    epoch = 0  
    episodes_per_epoch = 70  
    episode = 0  
    train_every_n = 2  
    training_iterations = 500  
    batch_size = 32  
    max_steps = 300  
    steps = 0  
    load_saved_buffer = False  
    pretrain = False
    pretraining_iterations = (50)
    seed = 42
    save_every = 100    
    data_file_path = "src/RLproject4/data.yml"

    model = SAC(state_dim=state_dim,action_dim=action_dim,max_action=max_action,device=device,save_every=save_every,load_model=False,)  
     
    ros = GazeboEnv()  
    eval_scenarios = record_eval_positions(n_eval_scenarios=nr_eval_episodes)  
    
    if load_saved_buffer:
        
        pretraining = Pretraining(file_names=[data_file_path],model=model,replay_buffer=ReplayBuffer(buffer_size=5e3, random_seed=seed),reward_function=ros.get_reward)
        replay_buffer = (pretraining.load_buffer())  
        
        if pretrain:
            pretraining.train(pretraining_iterations=pretraining_iterations,replay_buffer=replay_buffer,iterations=training_iterations,batch_size=batch_size)  # run pre-training
    
    else:
        replay_buffer = ReplayBuffer(buffer_size=5e3, random_seed=seed)  

    latest_scan, distance, cos, sin, collision, goal, a, reward = ros.step(lin_velocity=0.0, ang_velocity=0.0)

    while epoch < max_epochs:  
        
        state, terminal = model.prepare_state(latest_scan, distance, cos, sin, collision, goal, a)
        action = model.get_action(state, True)  
        action = (action + np.random.normal(0, 0.2, size=action_dim)).clip(-max_action, max_action)
        a_in = [(action[0] + 1) / 2,action[1],]  

        latest_scan, distance, cos, sin, collision, goal, a, reward = ros.step(lin_velocity=a_in[0], ang_velocity=a_in[1])  
        next_state, terminal = model.prepare_state(latest_scan, distance, cos, sin, collision, goal, a)  
        replay_buffer.add(state, action, reward, terminal, next_state)  

        if (terminal or steps == max_steps):      
            latest_scan, distance, cos, sin, collision, goal, a, reward = ros.reset()
            episode += 1
            if episode % train_every_n == 0:
                model.train(replay_buffer=replay_buffer,iterations=training_iterations,batch_size=batch_size)  
            steps = 0
        else:
            steps += 1
        if (episode + 1) % episodes_per_epoch == 0:  
            episode = 0
            epoch += 1
            eval(model=model,env=ros,scenarios=eval_scenarios,epoch=epoch,max_steps=max_steps)  

def eval(model, env, scenarios, epoch, max_steps):    
    print("..............................................")
    print(f"Epoch {epoch}. Evaluating {len(scenarios)} scenarios")
    avg_reward = 0.0
    col = 0
    gl = 0
    for scenario in scenarios:
        count = 0
        latest_scan, distance, cos, sin, collision, goal, a, reward = env.eval(scenario=scenario)
        while count < max_steps:
            state, terminal = model.prepare_state(latest_scan, distance, cos, sin, collision, goal, a)
            if terminal:
                break
            action = model.get_action(state, False)
            a_in = [(action[0] + 1) / 2, action[1]]
            latest_scan, distance, cos, sin, collision, goal, a, reward = env.step(lin_velocity=a_in[0], ang_velocity=a_in[1])
            avg_reward += reward
            count += 1
            col += collision
            gl += goal
    avg_reward /= len(scenarios)
    avg_col = col / len(scenarios)
    avg_goal = gl / len(scenarios)
    print(f"Average Reward: {avg_reward}")
    print(f"Average Collision rate: {avg_col}")
    print(f"Average Goal rate: {avg_goal}")
    print("..............................................")
    model.writer.add_scalar("eval/avg_reward", avg_reward, epoch)
    model.writer.add_scalar("eval/avg_col", avg_col, epoch)
    model.writer.add_scalar("eval/avg_goal", avg_goal, epoch)

if __name__ == "__main__":
    main()
