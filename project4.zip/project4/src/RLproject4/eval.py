from pathlib import Path

from SAC import SAC
from gazebo_env import GazeboEnv

from train import record_eval_positions
import torch
import numpy as np


def eval(model, env, scenarios, max_steps):
    """Function to run evaluation"""
    print("..............................................")
    print(f"Evaluating {len(scenarios)} scenarios")
    avg_reward = 0.0
    col = 0
    gl = 0
    for scenario in scenarios:
        count = 0
        latest_scan, distance, cos, sin, collision, goal, a, reward = env.eval(
            scenario=scenario
        )
        while count < max_steps:
            state, terminal = model.prepare_state(
                latest_scan, distance, cos, sin, collision, goal, a
            )
            if terminal:
                break
            action = model.get_action(state, False)
            a_in = [(action[0] + 1) / 2, action[1]]
            latest_scan, distance, cos, sin, collision, goal, a, reward = env.step(
                lin_velocity=a_in[0], ang_velocity=a_in[1]
            )
            avg_reward += reward
            count += 1
            col += collision
            gl += goal
    avg_reward /= len(scenarios)
    avg_col = col / len(scenarios)
    avg_goal = gl / len(scenarios)
    print(f"Average Reward: {avg_reward}")
    print(f"Average Collision rate: {avg_col}")
    print(f"Average Goal rate: {avg_goal}")
    print("..............................................")


def main():
    
    action_dim = 2  
    max_action = 1  
    state_dim = 25  
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")  
    nr_eval_episodes = 10  
    max_steps = 300  

    model = SAC(
        state_dim=state_dim,
        action_dim=action_dim,
        max_action=max_action,
        device=device,
        save_every=0, 
        load_model=True,
    )
    
    ros = GazeboEnv()

    eval_scenarios = record_eval_positions(n_eval_scenarios=nr_eval_episodes)

    for run in range(10):
        print(f"\nRunning evaluation {run + 1}/10...")
        eval(model=model, env=ros, scenarios=eval_scenarios, max_steps=max_steps)

if __name__ == "__main__":
    main()
