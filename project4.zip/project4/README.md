# Training Data

- Training Data, Trained Models and Final PPT can be found at this [link](https://wpi0-my.sharepoint.com/:f:/g/personal/rkulkarni1_wpi_edu/EuphptYulbVBrZvv7fRh80kBDPJw8423z7J5Ywi4WmkX6g?e=pC9pax)

- To visualize training data, extract the runs folder and choose the experiment you want and then execute:  
```bash
tensorboard --logdirs=runs
```

# Installation Instructions

- Install ROS2 Humble (or any depending on OS) using the official docs [ROS2 Humble Docs](https://docs.ros.org/en/humble/Installation.html)

- Clone this repo, then 
```bash
cd project4
```
```bash
sudo apt install python3-rosdep2
rosdep update
rosdep install -i --from-path src --rosdistro $ROS_DISTRO -y
sudo apt update
sudo apt install python3-colcon-common-extensions 
colcon build
```

- Add the below to your .bashrc file

```bashrc
#######################################################
# DEEP RL STUFF
#######################################################
# ROS2 domain id for network communication, machines with the same ID will receive each others' messages
export ROS_DOMAIN_ID=1

# Fill in the path to where you cloned the repo
WORKSPACE_DIR=~/reinforcement-learning/project4
export DRLNAV_BASE_PATH=$WORKSPACE_DIR

# Source the workspace
source $WORKSPACE_DIR/install/setup.bash

# Allow gazebo to find our turtlebot3 models
export GAZEBO_MODEL_PATH=$GAZEBO_MODEL_PATH:$WORKSPACE_DIR/src/turtlebot3_simulations/turtlebot3_gazebo/models

# Select which turtlebot3 model we will be using
export TURTLEBOT3_MODEL=waffle
# Allow Gazebo to find the plugin for moving the obstacles 
export GAZEBO_PLUGIN_PATH=$GAZEBO_PLUGIN_PATH:$WORKSPACE_DIR/src/turtlebot3_simulations/turtlebot3_gazebo/models/obstacle_plugin/lib
```


# Run the code

- Gazebo Simulation
```bash
ros2 launch turtlebot3_gazebo ros2_drl.launch.py
```

- Training
```bash
cd project4 && python3 RLproject4/train.py
```

- Evaluation
```bash
cd project4 && python3 RLproject4/eval.py
```